import React, { useEffect, useState } from "react";
import { MapContainer, TileLayer } from "react-leaflet";
import L from "leaflet";
import "leaflet.heat";
import axios from "axios";

const HeatLayer = ({ points }) => {
  const map = window._leaflet_map;

  useEffect(() => {
    if (!map) return;

    // Remove old heat layer
    if (window._heatLayer) {
      map.removeLayer(window._heatLayer);
    }

    if (!points || points.length === 0) return;

    const heatPoints = points.map(p => [
      p.lat,
      p.lng,
      p.intensity
    ]);

    window._heatLayer = L.heatLayer(heatPoints, {
      radius: 30,
      blur: 20,
      maxZoom: 17,
      gradient: {
        0.1: "blue",
        0.3: "lime",
        0.5: "yellow",
        0.7: "orange",
        1.0: "red"
      }
    }).addTo(map);

  }, [points]);

  return null;
};
const ComplaintHeatmap = () => {
  const [points, setPoints] = useState([]);

  useEffect(() => {

  const fetchHeatmap = () => {
    axios
      .get("http://127.0.0.1:8000/api/complaints/heatmap/")
      .then(res => setPoints(res.data.points))
      .catch(err => console.error(err));
  };

  // initial load
  fetchHeatmap();

  // auto refresh every 5 seconds
  const interval = setInterval(fetchHeatmap, 5000);

  return () => clearInterval(interval);

}, []);
  return (
    <MapContainer
      center={[20.5937, 78.9629]}   // India center
      zoom={5}
      style={{ height: "500px", width: "100%" }}
      whenCreated={(map) => (window._leaflet_map = map)}
    >
      <TileLayer
        attribution='© OpenStreetMap contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <HeatLayer points={points} />
    </MapContainer>
  );
};

export default ComplaintHeatmap;
